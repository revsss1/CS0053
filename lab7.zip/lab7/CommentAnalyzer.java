import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Point2D;
import java.awt.geom.RoundRectangle2D;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.StringTokenizer;
import javax.swing.*;

public class CommentAnalyzer extends JFrame implements ActionListener {
    private JTextArea comment, feedback;
    private JButton[] funcBtn = new Button[3];
    private HashSet<String> positiveWords, negativeWords;

    public CommentAnalyzer() {
        positiveWords = loadWordsFromFile("positive.txt");
        negativeWords = loadWordsFromFile("negative.txt");

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 470);
        setLocationRelativeTo(null);
        setTitle("Comment Analyzer");
        setResizable(false);
        setLayout(null);

        JPanel panel = new Panel(); 
        panel.setLayout(null); 
        panel.setBounds(0, 0, getWidth(), getHeight());
        add(panel);

        Font defaultFont = new Font("Arial", Font.PLAIN, 14);

        int y = 30;
        int labelWidth = 100;
        int labelHeight = 30;
        int textAreaWidth = 320;
        int textAreaHeight = 100;
        int spacing = 20;

        JLabel commentLabel = new JLabel("Comment:");
        commentLabel.setFont(defaultFont);
        commentLabel.setBounds(30, y, labelWidth, labelHeight);
        panel.add(commentLabel);

        comment = new TextArea(); 
        comment.setFont(defaultFont);
        comment.setBounds(30, y + labelHeight, textAreaWidth, textAreaHeight);
        comment.setEditable(true);
        comment.setBorder(null); 

        JScrollPane commentScrollPane = new JScrollPane(comment);
        commentScrollPane.setBounds(30, y + labelHeight, textAreaWidth, textAreaHeight); 
        commentScrollPane.setBorder(null);
        ScrollBar.applyMinimalScrollBar(commentScrollPane);
        panel.add(commentScrollPane);
        

        y += labelHeight + textAreaHeight + spacing;

        JLabel feedbackLabel = new JLabel("Feedback:");
        feedbackLabel.setFont(defaultFont);
        feedbackLabel.setBounds(30, y, labelWidth, labelHeight);
        panel.add(feedbackLabel);

        feedback = new TextArea(); 
        feedback.setFont(defaultFont);
        feedback.setBounds(30, y + labelHeight, textAreaWidth, textAreaHeight);
        feedback.setEditable(false);
        panel.add(feedback);

        y += labelHeight + textAreaHeight + spacing + 20;

        String[] buttonHeaders = {"ANALYZE", "CLEAR", "CANCEL"};
        int buttonWidth = 100;
        int buttonHeight = 30;
        int buttonSpacing = 10;

        for (int i = 0; i < buttonHeaders.length; i++) {
            funcBtn[i] = new Button(buttonHeaders[i]); 
            funcBtn[i].setFont(defaultFont);
            funcBtn[i].setBackground(new Color(0xD8BFD8));
            funcBtn[i].setForeground(Color.white);
            funcBtn[i].addActionListener(this);
            funcBtn[i].setBounds(30 + (i * (buttonWidth + buttonSpacing)), y, buttonWidth, buttonHeight);
            panel.add(funcBtn[i]);

            final int index = i;
            funcBtn[i].addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent evt) {
                    funcBtn[index].setBackground(new Color(0xD8BFD8).darker());
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent evt) {
                    funcBtn[index].setBackground(new Color(0xD8BFD8));
                }
            });
        }

        setVisible(true);
    }

    private HashSet<String> loadWordsFromFile(String filename) {
        HashSet<String> words = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                words.add(line.trim().toLowerCase());
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error loading words from " + filename, "File Error", JOptionPane.ERROR_MESSAGE);
        }
        return words;
    }

    private void analyzeComment() {
        String commentText = comment.getText().trim();
    
        if (commentText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a comment.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        if (commentText.split("\\.").length > 1) {
            JOptionPane.showMessageDialog(this, "Only one sentence is allowed.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
    
        commentText = commentText.replaceAll("[^a-zA-Z0-9\\s]", "").toLowerCase();
    
        StringTokenizer tokenizer = new StringTokenizer(commentText);
        int positiveCount = 0, negativeCount = 0;
        StringBuilder positiveWordsList = new StringBuilder();
        StringBuilder negativeWordsList = new StringBuilder();
    
        boolean containsNot = false;
        String previousWord = null;
    
        while (tokenizer.hasMoreTokens()) {
            String word = tokenizer.nextToken();
    
            if (word.equals("not")) {
                containsNot = true;
            } else {
                
                if (containsNot) {
                    if (positiveWords.contains(word)) {
                        negativeCount++;
                        if (negativeWordsList.length() > 0) {
                            negativeWordsList.append(", ");
                        }
                        negativeWordsList.append("not " + word);
                    } else if (negativeWords.contains(word)) {
                        positiveCount++;
                        if (positiveWordsList.length() > 0) {
                            positiveWordsList.append(", ");
                        }
                        positiveWordsList.append("not " + word);
                    }
                    containsNot = false; 
                } else {
                    
                    if (positiveWords.contains(word)) {
                        positiveCount++;
                        if (positiveWordsList.length() > 0) {
                            positiveWordsList.append(", ");
                        }
                        positiveWordsList.append(word);
                    } else if (negativeWords.contains(word)) {
                        negativeCount++;
                        if (negativeWordsList.length() > 0) {
                            negativeWordsList.append(", ");
                        }
                        negativeWordsList.append(word);
                    }
                }
            }
            previousWord = word;
        }
    
        String feedbackMessage = "Positive words: " + positiveCount;
        if (positiveCount > 0) {
            feedbackMessage += " [" + positiveWordsList.toString() + "]";
        }
        
    
        feedbackMessage += "\nNegative words: " + negativeCount;
        if (negativeCount > 0) {
            feedbackMessage += " [" + negativeWordsList.toString() + "]";
        }
    
        feedback.setText(feedbackMessage);
    
        if (positiveCount > negativeCount && !containsNot) {
            showMessage("<html>The result is: <b><br><span style='font-size:40px; color:#435274;'>positive</span></b></html>", "Positive Feedback", JOptionPane.INFORMATION_MESSAGE);
        } else {
            showMessage("<html>The result is: <b><br><span style='font-size:40px; color:#963939;'>negative</span></b></html>", "Constructive Feedback", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == funcBtn[0]) { 
            analyzeComment();
        } else if (e.getSource() == funcBtn[1]) { 
            comment.setText("");
            feedback.setText("");
        } else if (e.getSource() == funcBtn[2]) {
            System.exit(0);
        }
    }

    private void showMessage(String message, String title, int messageType) {
        Font defaultFont = new Font("Segoe UI", Font.PLAIN, 14);

        JPanel panel = new JPanel();
        JLabel label = new JLabel(message);
        label.setFont(defaultFont);
        panel.add(label);

        JButton btn;

        if (messageType == JOptionPane.INFORMATION_MESSAGE) {
            btn = new Button("EXIT");
            btn.setBackground(new Color(229, 217, 242));
            btn.setFont(defaultFont);
        } else {
            btn = new Button("OK");
            btn.setBackground(new Color(244, 193, 193));
            btn.setFont(defaultFont);
        }

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(btn.getBackground().brighter());
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(messageType == JOptionPane.INFORMATION_MESSAGE ? new Color(229, 217, 242)
                        : new Color(244, 193, 193));
            }
        });

        btn.addActionListener(e -> {
            ((JDialog) SwingUtilities.getWindowAncestor(panel)).dispose();
        });

        Object[] options = { btn };

        JOptionPane.showOptionDialog(
                this,
                panel,
                title,
                JOptionPane.DEFAULT_OPTION,
                messageType,
                null,
                options,
                options[0]);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CommentAnalyzer());
    }
}

class Panel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        int w = getWidth();
        int h = getHeight();
        float radius = Math.max(w, h) /  1;

        int offsetX = (int) (w * 0.50);
        int offsetY = (int) (h * -0.00);

        Color color3 = new Color(255, 255, 255);
        Color color2 = new Color(0xFFF5EE);
        Color color1 = new Color(0xD8BFD8);

        RadialGradientPaint radialGradientPaint = new RadialGradientPaint(
                new Point2D.Float(offsetX, offsetY), radius,
                new float[] { 0f, 0.6f, 1f },
                new Color[] { color1, color2, color3 });

        g2d.setPaint(radialGradientPaint);
        g2d.fillRect(0, 0, w, h);
    }
}

class Button extends JButton {
    private int shadowSize = 2;

    public Button(String label) {
        super(label);
        setFocusable(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setColor(new Color(0, 0, 0, 50));
        g2.fillRoundRect(shadowSize, shadowSize, getWidth() - shadowSize, getHeight() - shadowSize, 20, 20);

        g2.setColor(getBackground());
        g2.fillRoundRect(0, 0, getWidth() - shadowSize, getHeight() - shadowSize, 20, 20);

        super.paintComponent(g);
    }

    @Override
    protected void paintBorder(Graphics g) {
    }
}

class TextArea extends JTextArea {
    private int cornerRadius = 15;

    public TextArea() {
        super();
        setOpaque(false); 
        setWrapStyleWord(true); 
        setLineWrap(true); 
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D graphics = (Graphics2D) g.create();
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); 

        graphics.setColor(getBackground());
        graphics.fillRoundRect(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius);

        graphics.setClip(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), cornerRadius, cornerRadius));
        super.paintComponent(graphics); 
        graphics.dispose();
    }

    @Override
    protected void paintBorder(Graphics g) {
        Graphics2D graphics = (Graphics2D) g.create();
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); 

        graphics.setColor(new Color(200, 200, 200)); 
        graphics.setStroke(new BasicStroke(2)); 

        graphics.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, cornerRadius, cornerRadius);
        graphics.dispose();
    }

    @Override
    public Insets getInsets() {
        return new Insets(5, 10, 5, 10); 
    }
}

class ScrollBar extends javax.swing.plaf.basic.BasicScrollBarUI {
    @Override
    protected void configureScrollBarColors() {
        thumbColor = Color.GRAY;
    }

    @Override
    protected JButton createDecreaseButton(int orientation) {
        return createInvisibleButton();
    }

    @Override
    protected JButton createIncreaseButton(int orientation) {
        return createInvisibleButton();
    }

    @Override
    protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
        
    }

    @Override
    protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
        if (thumbBounds.isEmpty() || !scrollbar.isEnabled()) {
            return;
        }

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setPaint(thumbColor);
        g2.fillRoundRect(thumbBounds.x, thumbBounds.y, thumbBounds.width, thumbBounds.height, 10, 10);
        g2.dispose();
    }

    private JButton createInvisibleButton() {
        JButton button = new JButton();
        button.setPreferredSize(new Dimension(0, 0));
        button.setMinimumSize(new Dimension(0, 0));
        button.setMaximumSize(new Dimension(0, 0));
        return button;
    }

    public static void applyMinimalScrollBar(JScrollPane scrollPane) {
        scrollPane.getVerticalScrollBar().setUI(new ScrollBar());
        scrollPane.getHorizontalScrollBar().setUI(new ScrollBar());
        scrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(6, Integer.MAX_VALUE)); 
        scrollPane.getHorizontalScrollBar().setPreferredSize(new Dimension(Integer.MAX_VALUE, 6)); 
        scrollPane.getVerticalScrollBar().setOpaque(false);
        scrollPane.getHorizontalScrollBar().setOpaque(false);
    }
}